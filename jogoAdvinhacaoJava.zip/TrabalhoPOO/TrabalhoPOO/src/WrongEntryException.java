public class WrongEntryException extends Exception{
    public WrongEntryException(String message){
        super(message);
    }
}
