public interface FuncionamentoModificador {
     void nomeModalidade();
     void descricao();
     void maxTentativas();
     void tipoModificador();
}
