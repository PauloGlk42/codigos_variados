public interface Modificador {

    String embaralhaPalavra(String palavra);

}

